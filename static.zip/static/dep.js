const selectBox = document.querySelector("#select-inp");
const choiceUl = document.querySelector("#box-ul");
const selectTxt = document.querySelector("#dep-txt");
const depInp = document.querySelector("#dep-inp")



selectBox.addEventListener("click", preSet);
function preSet(){

let y = choiceUl.getAttribute("class");
if (y == "hide"){

choiceUl.className = "main-ul";
};

if(y == "main-ul"){
choiceUl.className = "hide";

};



let s = choiceUl.querySelectorAll('li');

Array.from(s).forEach(function(l){l.addEventListener("click",addChoice);

console.log(l);

});
};

function addChoice(e){
let z = e.target;
console.log(z);
let t = z.querySelector(".choice-txt");
let a = z.innerText;
let b = selectBox.querySelector(".select-txt");
b.innerHTML= a;

depInp.setAttribute("value","");
depInp.setAttribute("value",a);
console.log(depInp);

choiceUl.className = "hide";

};