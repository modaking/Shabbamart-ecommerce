const x = document.querySelector("#tags-ul");
const count = document.querySelector("#num-1");
const tgIn = document.querySelector("#tag_names")
const tgOut = document.querySelector("#tag_out")
let tags = [];
let maxTags = 10;

countTags();
newVal();

function countTags(){
        count.innerHTML = maxTags - tags.length ;

};


function createTag(){
    x.querySelectorAll("li").forEach(li => li.remove());
    tags.forEach(tag =>{
        const liTag = document.createElement("li");
        const remove = document.createElement("span")
        const tagtxt = document.createElement("span")

        tagtxt.innerHTML = tag;
        liTag.setAttribute('id',tag);
        remove.textContent = 'x';

        liTag.className = "li-tag"
        tagtxt.className = "tag-txt";
        remove.className = "icon-1";


        liTag.appendChild(tagtxt);
        liTag.appendChild(remove);

        x.appendChild(liTag);

       removeTag();

        newVal();
        });
        newVal();
        countTags();
};

function addTag(e){
    if(e.key == "Control"){
        let tag = e.target.value.replace(/\s+/g, '');

        if(tag.length > 1 && !tags.includes(tag)){
           if(tags.length < 10){
                tag.split(',').forEach(tag=>{
                    tags.push(tag);
                    createTag();

                });
            }
        }
        e.target.value = "";
    }
    newVal();
}
function removeTag(){

        let n = x.querySelectorAll('li');

        Array.from(n).forEach(function(h){h.addEventListener("click",deleteTag);
});
};
 function deleteTag(e){

                let g = e.target.parentElement;
                let f = g.getAttribute('id');
                let m = g.querySelector('.tag-txt');
                let y = m.innerHTML;


                let index = tags.indexOf(f);

                var lon = tags.length -1;


                x.removeChild(g);
                tags.splice(index,1);

                countTags();


};


function newVal(){
 var lun = tags.length ;
     let tgStr = "";
     for(var i=0; i<lun; i++){

     tgStr+=tags[i] +",";
     tgOut.setAttribute("value","");
     tgOut.setAttribute("value",tgStr);

     };
     console.log(tgOut);
     console.log(tgOut.getAttribute("value"));






    };




x.addEventListener("keyup", addTag);

const removeBtn = document.querySelector("#button-1");


removeBtn.addEventListener("click",() =>{
    tags.length = 0;
    x.querySelectorAll("li").forEach(li => li.remove());

    countTags();
    newVal();
});
