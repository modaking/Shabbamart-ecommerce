
$(document).ready(function(){

$(".profile").click(function(){
     const bod = document.querySelector("body");

     var x = bod.querySelector('.prof_section');
     var pin = bod.querySelector('.pinned_section');
     var menu = bod.querySelector('.menu_section');

     var cart = bod.querySelector('.cart_section');

     if (x){
          bod.removeChild(x);
          bod.style.overflow = 'scroll';

     }
     else{

      if (pin){
          bod.removeChild(pin);


     }
     else if(cart){

     bod.removeChild(cart);
     }
     else if(menu){

     bod.removeChild(menu);
     }

           bod.style.overflow = 'hidden';

      $.ajax({
      data: {
      digit: ""

      },
      type: "GET",
      url:"/view_profile"})
      .done(function(data){
      console.log(data.digit)
     /* create profile section */
     const profSection = document.createElement("div");

     const titleSection = document.createElement("div");
     const title = document.createElement("div");
     const removeCont = document.createElement("div");
     const remove = document.createElement("img");

     const mainSection = document.createElement("div");

     const secOne = document.createElement("div");

     const identityCont = document.createElement("div");
     const iddetailsCont = document.createElement("div");
     const name = document.createElement("span");
     const email = document.createElement("span");
     const phone = document.createElement("span");


     const infoCont = document.createElement("div");
     const tallyCont = document.createElement("div");
     const tallyone = document.createElement("div");
     const tallytwo = document.createElement("div");
     const tallythree = document.createElement("div");
     const ordersTxt = document.createElement("span");
     const ordersNo = document.createElement("span");
     const pendingTxt = document.createElement("span");
     const pendingNo = document.createElement("span");
     const salesTxt = document.createElement("span");
     const salesNo = document.createElement("span");


     const secTwo = document.createElement("div");

     const pendingCont = document.createElement("div");

     const ordersCont = document.createElement("div");




     name.classList.add("prof_name");
     email.classList.add("prof_email");
     phone.classList.add("prof_phone");
     profSection.classList.add("prof_section");
     titleSection.classList.add("title_cont");
     title.classList.add("title_txt");
     removeCont.classList.add("remove_cont");
     remove.classList.add("remove");
     mainSection.classList.add("main_cont");
     secOne.classList.add("section_one");
     identityCont.classList.add("identity_cont");
     iddetailsCont.classList.add("details_cont");
     infoCont.classList.add("info_cont");
     tallyCont.classList.add("tally_cont");
     tallyone.classList.add("tally_one");
     tallytwo.classList.add("tally_two");
     tallythree.classList.add("tally_three");
     ordersTxt.classList.add("orders_txt");
     ordersNo.classList.add("orders_no");
     pendingTxt.classList.add("pending_txt");
     pendingNo.classList.add("pending_no");
     salesTxt.classList.add("sales_txt");
     salesNo.classList.add("sales_no");
     secTwo.classList.add("section_two");
     pendingCont.classList.add("pending_cont");
     ordersCont.classList.add("orders_cont");


     name.textContent = "Name: Ian Mwangi"
     email.textContent = "Email: ian9toz@gmail.com"
     phone.textContent = "Phone: 254715344405"
     ordersTxt.textContent = "Orders"
     ordersNo.textContent = "300"
     pendingTxt.textContent = "Pending"
     pendingNo.textContent = "5"
     salesTxt.textContent = "Spent"
     salesNo.textContent = "Ksh 3000"
     remove.setAttribute("src", "/static/icons/arrow_left.png");
     title.textContent = "Profile"


     removeCont.appendChild(remove);
     titleSection.appendChild(removeCont);
     titleSection.appendChild(title);


     iddetailsCont.appendChild(name);
     iddetailsCont.appendChild(email);
     iddetailsCont.appendChild(phone);



     identityCont.appendChild(iddetailsCont);


     tallyone.appendChild(ordersTxt);
     tallyone.appendChild(ordersNo);
     tallytwo.appendChild(pendingTxt);
     tallytwo.appendChild(pendingNo);
     tallythree.appendChild(salesTxt);
     tallythree.appendChild(salesNo);

     tallyCont.appendChild(tallyone);
     tallyCont.appendChild(tallytwo);
     tallyCont.appendChild(tallythree);

     infoCont.appendChild(tallyCont);

     secOne.appendChild(identityCont);
     secOne.appendChild(infoCont);

     secTwo.appendChild(pendingCont);
     secTwo.appendChild(ordersCont);

     mainSection.appendChild(secOne);
     mainSection.appendChild(secTwo);

     profSection.appendChild(titleSection);
     profSection.appendChild(mainSection);
     bod.appendChild(profSection);

     
          remove.addEventListener("click", function(e) {
          const bod = document.querySelector("body")
          var tx = e.target.parentElement.parentElement;
          tx = tx.parentElement;
          console.log(tx)
          bod.removeChild(tx);
          bod.style.overflow = 'scroll';

         });


        })




      }


   })


})
