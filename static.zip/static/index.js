const body = document.querySelector("body");
const gallery = document.querySelector("#gallery");

/*body.addEventListener("resize", readme);*/

function readme(){
var x = screen.height;
var y = screen. width;
if (y <=430){
const prods = document.querySelectorAll("#prod_card");
Array.from(prods).forEach(function(h){

const image = h.querySelector('img')
const link = document.createElement("a");
var z = image.getAttribute("id");
console.log(z);
link.setAttribute("href","description/" + z)

 link.appendChild(image)
 h.appendChild(link)


});


}
}

window.onload = readme;
window.onresize = readme;