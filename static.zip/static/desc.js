$(".cart_btn").click(function(){
      $.ajax({
      data: {


      },
      type: "GET",
      url:"/add_cart/" + $(".item_btns").attr("id")})
      .done(function(data){
      console.log(data.digit)
     /* flash relevant message of cart add status */


      });



});

$(".pin_btn").click(function(){
      $.ajax({
      data: {


      },
      type: "GET",
      url:"/add_pin/" + $(".item_btns").attr("id")})
      .done(function(data){
      console.log(data.digit)
     /* flash relevant message of cart add status */


      });



});