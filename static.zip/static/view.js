
function openPopup() {
  document.getElementById("overlay").style.display = "block";
  document.getElementById("popup").style.display = "flex";
}

function closePopup() {
  document.getElementById("overlay").style.display = "none";
  document.getElementById("popup").style.display = "none";
}


$(document).ready(function(){

const bod = document.querySelector("body");



$(".cart").click(function(){

const popup = document.querySelector(".popup");

const app = popup.querySelector(".inner_section");

if (app){
popup.removeChild(app);
}


     var pin = bod.querySelector('.pinned_section');
     var prof = bod.querySelector('.prof_section');
     var menu = bod.querySelector('.menu_section');

     var x = bod.querySelector('.cart_section');



      $.ajax({
      data: {
      digit: ""

      },
      type: "GET",
      url:"/view_cart"})
      .done(function(data){
      console.log(data.digit)
     /* create cart section */

     const section = document.createElement("div")
     const innerSection = document.createElement("div");
     const mainSection = document.createElement("div");
     const itemSection = document.createElement("div");
     const titleSection = document.createElement("div");
     const items = document.createElement("ul")
     const btnCont = document.createElement("div")
     const total = document.createElement("span")
     const btn = document.createElement("a")
     const remove = document.createElement("div")
     const removeIcon =document.createElement("img")
     var list = data.digit;

     items.classList.add("cart_cont")

      list.forEach(it =>{
        const liCart = document.createElement("li");
        const imgCont = document.createElement("div");
        const info = document.createElement("div");
        const btnSection = document.createElement("div");

        const img = document.createElement("img");

        const name = document.createElement("span");
        const price = document.createElement("span");
        const quantityCont = document.createElement("div");
        const quantity = document.createElement("input");
        const inc = document.createElement("span");
        const decr = document.createElement("span");

        const multi = document.createElement("span");
        const delCont = document.createElement("div");
        const del = document.createElement("span");

        img.setAttribute("src",it['path']);
        name.textContent ="Name:"+ it['name'];
        price.textContent = "Price: Ksh " +it['price'];
        quantity.setAttribute("type","number")
        quantity.setAttribute("name","quantity")
        quantity.value = it['quantity'];
        quantityCont.textContent = "Qty: "
        multi.textContent = " Ksh " +it['price'] * it['quantity'];
        del.textContent = 'Remove';
        inc.textContent = '+';
        decr.textContent ='-';

        liCart.classList.add("item");
        imgCont.classList.add("img_cont");
        img.classList.add("img_obj");
        info.classList.add("cart_details");
        btnSection.classList.add("actions");
        name.classList.add("item_name");
        price.classList.add("item_price");
        quantityCont.classList.add("quantity_cont");
        quantity.classList.add("item_quantity");
        multi.classList.add("order_cost");
        delCont.classList.add("delete_cont");
        del.classList.add("delete");
        inc.classList.add("increment");
        decr.classList.add("decrement");


        imgCont.appendChild(img);

        info.appendChild(name);

        quantityCont.appendChild(decr);
        quantityCont.appendChild(quantity);
        quantityCont.appendChild(inc);
        info.appendChild(quantityCont);
        info.appendChild(price);

        btnSection.appendChild(multi);
        delCont.appendChild(del);
        btnSection.appendChild(delCont);


        liCart.appendChild(imgCont);
        liCart.appendChild(info);
        liCart.appendChild(btnSection);


        items.appendChild(liCart);


        del.addEventListener("click", function(e) {
               $.ajax({
                   data: {
                   result: ""

                   },
                   type: "GET",
                   url:"/del_cart/" + it['id']})
                  .done(function(data){
                 console.log(data.result)
                 var z = e.target.parentElement;
                 const n = document.querySelector('.cart_cont')
                 var cs = document.querySelector('.cart_section')
                 cb = cs.querySelector('.charge_section')
                 cd = cb.querySelector('.total_amount')
                 cd.textContent = "Total:Ksh " + data.total_amount;


                 if(data.total_amount==0){
                     cn = cb.querySelector('.buy_btn');
                     console.log(cn)
                     cb.removeChild(cn);


                  };

                 z = z.parentElement;
                 z = z.parentElement;
                 console.log(z);
                  n.removeChild(z);



                    });
               });

               inc.addEventListener('click', function(e) {
                    var v = e.target.parentElement;
                      var tp = v.parentElement;

                      tp = tp.parentElement;
                      tp = tp.querySelector('.order_cost');
                      v = v.querySelector('.item_quantity')

                    var hh = v.value;
                    hh++;
                    v.value =hh;
                    console.log(v.value)
                    console.log('item id:'+ it['id'] )
                  $.ajax({
                   data: {
                   result: ""

                   },
                   type: "GET",
                   url:"/cart_quantity/" + it['id']+"/"+v.value})
                  .done(function(data){
                 console.log(data.result)
                  /*change total cost */
                  console.log(tp)
                  tp.textContent = " Ksh "+data.result;
                   var cs = document.querySelector('.cart_section')
                 cs = cs.querySelector('.charge_section')
                 cs = cs.querySelector('.total_amount')
                 cs.textContent = "Total:Ksh " + data.total_amount;



                    });



               });

               decr.addEventListener('click', function(e) {

                    var v = e.target.parentElement;
                      var tp = v.parentElement;

                      tp = tp.parentElement;
                      tp = tp.querySelector('.order_cost');
                      v = v.querySelector('.item_quantity');

                    var hh = v.value;
                    if (hh>0){
                    hh--;
                    }
                    v.value = hh;
                    console.log(v.value);

                  $.ajax({
                   data: {
                   result: ""

                   },
                   type: "GET",
                   url:"/cart_quantity/" + it['id']+"/"+v.value})
                  .done(function(data){
                 console.log(data.result)
                 /*change total cost*/
                 tp.textContent = " Ksh " +data.result;
                  var cs = document.querySelector('.cart_section')
                 cs = cs.querySelector('.charge_section')
                 cs = cs.querySelector('.total_amount')
                 cs.textContent = "Total:Ksh " + data.total_amount;




                    });

               });

               quantity.addEventListener('keyup', function(e) {
                      var jv= e.target.value;
                      var jh= e.target.parentElement;
                      jh = jh.querySelector('.item_quantity')
                      var nn = 1;
                      var lu = 0;
                      var tp = jh.parentElement;
                      tp = tp.parentElement;
                      tp = tp.parentElement;
                      tp = tp.querySelector('.order_cost');




                      if (jv < 0){
                         jh.value =1;
                         jv = 1;
                         if (nn ==0){
                             nn = 1;
                         }

                      }

                      else if(jv>0){
                         var mn = jv;
                         jh.value =mn;

                         if(nn==0){
                             nn=1

                         }

                      }

                      else {
                         nn =0;

                      }



                      if(nn==0){
                      lu = nn
                      }
                      else{
                          lu=jv;

                      }

                      console.log(lu);

                    $.ajax({
                   data: {
                   result: ""

                   },
                   type: "GET",
                   url:"/cart_quantity/" + it['id']+"/"+lu})
                  .done(function(data){
                 console.log(data.result)
                   /* change total cost*/

                   tp.textContent = " Ksh " +data.result;
                    var cs = document.querySelector('.cart_section')
                 cs = cs.querySelector('.charge_section')
                 cs = cs.querySelector('.total_amount')
                 cs.textContent = "Total:Ksh " + data.total_amount;




                    });

               });


          });

         section.classList.add("cart_section");
         innerSection.classList.add("inner_section");
         itemSection.classList.add("items_section")
         items.classList.add("cart_cont");
         titleSection.classList.add("title_section")
         mainSection.classList.add("main_section");

         btn.textContent = "Buy";
         btn.setAttribute("href","/details")
         total.textContent = "Total:Ksh " + data.total_amount;

         btnCont.classList.add("charge_section");
         total.classList.add("total_amount");
         btn.classList.add("buy_btn");



         btnCont.appendChild(total) ;
         if (data.total_amount > 0){
         btnCont.appendChild(btn);
           };
         titleSection.appendChild(removeIcon);
         itemSection.appendChild(items)
         mainSection.appendChild(titleSection);
         mainSection.appendChild(itemSection);
         mainSection.appendChild(remove);
         innerSection.appendChild(mainSection);
         innerSection.appendChild(btnCont);
         popup.appendChild(innerSection);


         removeIcon.addEventListener("click", function(e) {

          x = e.target.parentElement;
          x = x.parentElement.parentElement.parentElement;
          console.log(x)
          bod.removeChild(x);
          bod.style.overflow = 'scroll';

         });


         });

/* end else here }; */
      });



$(".profile").click(function(){
     var x = bod.querySelector('.prof_section');
     var pin = bod.querySelector('.pinned_section');
     var menu = bod.querySelector('.menu_section');

     var cart = bod.querySelector('.cart_section');

     if (x){
          bod.removeChild(x);
          bod.style.overflow = 'scroll';

     }
     else{

       if (pin){
          bod.removeChild(pin);


     }
       else if(cart){

     bod.removeChild(cart);
     }
       else if(menu){

     bod.removeChild(menu);
     }

       bod.style.overflow = 'hidden';

      $.ajax({
      data: {
      digit: ""

      },
      type: "GET",
      url:"/view_profile"})
      .done(function(data){
      console.log(data.digit)
     /* create profile section */
     const profSection = document.createElement("div");

     const titleSection = document.createElement("div");
     const title = document.createElement("div");
     const removeCont = document.createElement("div");
     const remove = document.createElement("img");

     const mainSection = document.createElement("div");

     const secOne = document.createElement("div");

     const identityCont = document.createElement("div");
     const iddetailsCont = document.createElement("div");
     const name = document.createElement("span");
     const email = document.createElement("span");
     const phone = document.createElement("span");


     const infoCont = document.createElement("div");
     const tallyCont = document.createElement("div");
     const tallyone = document.createElement("div");
     const tallytwo = document.createElement("div");
     const tallythree = document.createElement("div");
     const ordersTxt = document.createElement("span");
     const ordersNo = document.createElement("span");
     const pendingTxt = document.createElement("span");
     const pendingNo = document.createElement("span");
     const salesTxt = document.createElement("span");
     const salesNo = document.createElement("span");


     const secTwo = document.createElement("div");

     const pendingCont = document.createElement("div");

     const ordersCont = document.createElement("div");




     name.classList.add("prof_name");
     email.classList.add("prof_email");
     phone.classList.add("prof_phone");
     profSection.classList.add("prof_section");
     titleSection.classList.add("title_cont");
     title.classList.add("title_txt");
     removeCont.classList.add("remove_cont");
     remove.classList.add("remove");
     mainSection.classList.add("main_section");
     secOne.classList.add("section_one");
     identityCont.classList.add("identity_cont");
     iddetailsCont.classList.add("details_cont");
     infoCont.classList.add("info_cont");
     tallyCont.classList.add("tally_cont");
     tallyone.classList.add("tally_one");
     tallytwo.classList.add("tally_two");
     tallythree.classList.add("tally_three");
     ordersTxt.classList.add("orders_txt");
     ordersNo.classList.add("orders_no");
     pendingTxt.classList.add("pending_txt");
     pendingNo.classList.add("pending_no");
     salesTxt.classList.add("sales_txt");
     salesNo.classList.add("sales_no");
     secTwo.classList.add("section_two");
     pendingCont.classList.add("pending_cont");
     ordersCont.classList.add("orders_cont");


     name.textContent = "Name: Ian Mwangi"
     email.textContent = "Email: ian9toz@gmail.com"
     phone.textContent = "Phone: 254715344405"
     ordersTxt.textContent = "Orders"
     ordersNo.textContent = "300"
     pendingTxt.textContent = "Pending"
     pendingNo.textContent = "5"
     salesTxt.textContent = "Spent"
     salesNo.textContent = "Ksh 3000"
     remove.setAttribute("src", "/static/icons/arrow_left.png");
     title.textContent = "Profile"


     removeCont.appendChild(remove);
     titleSection.appendChild(removeCont);
     titleSection.appendChild(title);


     iddetailsCont.appendChild(name);
     iddetailsCont.appendChild(email);
     iddetailsCont.appendChild(phone);



     identityCont.appendChild(iddetailsCont);


     tallyone.appendChild(ordersTxt);
     tallyone.appendChild(ordersNo);
     tallytwo.appendChild(pendingTxt);
     tallytwo.appendChild(pendingNo);
     tallythree.appendChild(salesTxt);
     tallythree.appendChild(salesNo);

     tallyCont.appendChild(tallyone);
     tallyCont.appendChild(tallytwo);
     tallyCont.appendChild(tallythree);

     infoCont.appendChild(tallyCont);

     secOne.appendChild(identityCont);
     secOne.appendChild(infoCont);

     secTwo.appendChild(pendingCont);
     secTwo.appendChild(ordersCont);

     mainSection.appendChild(secOne);
     mainSection.appendChild(secTwo);

     profSection.appendChild(titleSection);
     profSection.appendChild(mainSection);
     bod.appendChild(profSection);


          remove.addEventListener("click", function(e) {
          const bod = document.querySelector("body")
          var tx = e.target.parentElement.parentElement;
          tx = tx.parentElement;
          console.log(tx)
          bod.removeChild(tx);
          bod.style.overflow = 'scroll';

         });


        })




      }


   })



$(".pin_icon").click(function(e){
      var xbt= e.target;
      var pi = e.target.parentElement;
      pi = pi.parentElement;
      pi = pi.getAttribute("id");
      console.log(pi);

      $.ajax({
      data: {
      digit: ""

      },
      type: "GET",
      url:"/add_pin/" + pi})
      .done(function(data){
      console.log(data.digit)
     /* create cart section */
     xbt.setAttribute("src", "/static/icons/done.png")


         })




})



$(".pinned").click(function(e){

     console.log(bod);
     var mmn = bod.querySelector('.pinned_section');
     var prof = bod.querySelector('.prof_section');
     var menu = bod.querySelector('.menu_section');

     var cartt = bod.querySelector('.cart_section');


     if (mmn){
          bod.removeChild(mmn);
          bod.style.overflow = 'scroll';

     }
     else{
     if(cartt){
          bod.removeChild(cartt);


       }
       else if(prof){

           bod.removeChild(prof);
       }
       else if(menu){

            bod.removeChild(menu);
       }

bod.style.overflow = 'hidden';

$.ajax({
    data: {

        digit:""

    },type: "GET",
      url:"/view_pin"})
    .done(function(data){

     console.log(data.digit);

     const section = document.createElement("div");
     const titleBox = document.createElement("div");
     const removeIcon = document.createElement("img")
     const galleryBox = document.createElement("div");
     const items = document.createElement("ul");
     var list = data.digit;

     list.forEach(it =>{
        const item = document.createElement("li");
        const card = document.createElement("div");
        const descLink = document.createElement("a");
        const photo = document.createElement("img");
        const detailSection = document.createElement("div");
        const detailTxt = document.createElement("div");
        const nameTxt = document.createElement("span");
        const priceTxt = document.createElement("span");
        const varTxt = document.createElement("span");
        const iconSection = document.createElement("div");
        const unpin = document.createElement("img");
        const cart = document.createElement("img");


        card.classList.add("pinned_card");
        descLink.classList.add("pinned_link");
        photo.classList.add("pinned_photo");
        detailSection.classList.add("pinned_detail");
        detailTxt.classList.add("pinned_txt");
        nameTxt.classList.add("pinned_name");
        priceTxt.classList.add("pinned_price");
        varTxt.classList.add("pinned_var");
        iconSection.classList.add("pinned_btns");
        unpin.classList.add("unpin");
        cart.classList.add("pinned_cart");
        item.classList.add("pinned_item");

        var bv = it['id'];
        bv = bv.replace("p","");
        console.log("bv ->" + bv );
        console.log(it['path'])


        photo.setAttribute("src", it['path']);
        descLink.setAttribute("href", "description/" + bv);
        unpin.setAttribute("src", "/static/icons/close.png");
        cart.setAttribute("src", "/static/icons/add_shopping.png");
        iconSection.setAttribute("id", it['id']);
        nameTxt.textContent =it['name'];
        priceTxt.textContent =" Ksh " +it['price'];
        varTxt.textContent =it['category'];



        iconSection.appendChild(unpin);
        if(it['category']!="Shoes"){
        iconSection.appendChild(cart);
        }else if(it['category']!="Clothes and accessories"){
        iconSection.appendChild(cart);
        }
        detailTxt.appendChild(nameTxt);
        detailTxt.appendChild(priceTxt);
        detailTxt.appendChild(varTxt);
        detailSection.appendChild(detailTxt);
        detailSection.appendChild(iconSection);
        descLink.appendChild(photo);
        card.appendChild(descLink);
        card.appendChild(detailSection);
        item.appendChild(card);


        items.appendChild(item);


        cart.addEventListener("click", function(e) {


        var xp = e.target.parentElement;
        console.log(xp);
        xp = xp.getAttribute("id");
        console.log(xp);
        xp = xp.replace("p","")
        xp = parseInt(xp);
        console.log("xp ->" + xp )


        $.ajax({
            data: {

        digit:""

    },type: "GET",
      url:"/add_cart/" + xp})
    .done(function(data){
    console.log(data);


    })

       })




 unpin.addEventListener("click", function(e) {



        var xp = e.target.parentElement;
        console.log(xp);
        xp = xp.getAttribute("id");
        console.log(xp);
        xp = xp.replace("p","")
        xp = parseInt(xp);
        console.log("xp ->" + xp )


               $.ajax({
                   data: {
                   result: ""

                   },
                   type: "GET",
                   url:"/del_pin/" + xp})
                  .done(function(data){
                 console.log(data.result)
                 var z = e.target.parentElement.parentElement.parentElement.parentElement;
                 const n = document.querySelector('.pinned_ul');

                 console.log(z);
                 console.log(n);
                  n.removeChild(z);



                    });
               });

    });


     removeIcon.setAttribute("src", "/static/icons/arrow_left.png");
     section.classList.add("pinned_section");
     titleBox.classList.add("pinned_title");
     galleryBox.classList.add("pinned_gallery");
     items.classList.add("pinned_ul");
     removeIcon.classList.add("remove");

     titleBox.appendChild(removeIcon);
     galleryBox.appendChild(items);
     section.appendChild(titleBox);
     section.appendChild(galleryBox);
     bod.appendChild(section);


removeIcon.addEventListener("click", function(e) {

          var tx = e.target.parentElement;
          tx = tx.parentElement;
          console.log(tx)
          bod.removeChild(tx);
          bod.style.overflow = 'scroll';

         });

  })


}})



$(".add_icon").click(function(e){


      var xbt= e.target;
      console.log(xbt)
      var pi = e.target.parentElement;
      pi = pi.parentElement;
      pi = pi.getAttribute("id");
      console.log(pi);


      $.ajax({
      data: {


      },
      type: "GET",
      url:"/add_cart/" + pi})
      .done(function(data){

       xbt.setAttribute("src", "/static/icons/done.png")

});

})



   });
