const selectBox = document.querySelector(".category_inp");
const choiceUl = document.querySelector("#box-ul");


selectBox.addEventListener("click", preSet);
function preSet(){

let y = choiceUl.getAttribute("class");
if (y == "hide"){

choiceUl.className = "main-ul";
};

if(y == "main-ul"){
choiceUl.className = "hide";

};




let s = choiceUl.querySelectorAll('li');

Array.from(s).forEach(function(l){l.addEventListener("click",addChoice);

console.log(l);

});
};

function addChoice(e){
let z = e.target;
console.log(z);
let t = z.querySelector(".choice-txt");
let a = z.innerText;


selectBox.setAttribute("value","");
selectBox.setAttribute("value",a);
console.log(selectBox);

choiceUl.className = "hide";

};