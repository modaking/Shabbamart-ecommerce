const fileInput = document.querySelector("#file-input");
const varsInput = document.querySelector("#variations");
const imageCont = document.querySelector("#pre-prod");
const imgVars = document.querySelector("#pre-img")
const varsCont = document.querySelector("#vari-cont");
const prodCont = document.querySelector("#prod-cont");
const preUl = document.querySelector("#pre-ul");
const nameIn = document.querySelector("#variation_names")

let Variants = [];

console.log("Creating Variants")


function preview() {
    console.log("Reading")
    console.log(fileInput.value)
    const file =fileInput.files[0];


    if (file){
    console.log(file)
        imageCont.querySelectorAll("img").forEach(img => img.remove());

        const reader = new FileReader();
        const img = document.createElement("img");




        reader.onload = function(){
            const result = reader.result;
            img.setAttribute("src",result)
            img.classList.add("img_product")
            imageCont.appendChild(img)
        };
    reader.readAsDataURL(file);
        let x = prodCont.querySelector(".prod-txt")
        let y = file.length;
        x.textContent ='File chosen';

     };



};

function previewAll() {
    console.log("Reading-multiple")
    const files = varsInput.files;
    console.log(files)
    var q = files[0]
    console.log(q)
    delete files[0];
    console.log(files)

    if (files){
        console.log(files);
        imgVars.querySelectorAll("div").forEach(div => div.remove());
        imgVars.querySelectorAll("input").forEach(input => input.remove());
        Variants.length = 0;
        let indx = 0;
        console.log(varsInput.files[0])

        createName()
        for(i of files){
            console.log(i)

            const reader = new FileReader();
            const img = document.createElement("img");
            const nminput = document.createElement("input");
            const conta = document.createElement("div");
            const ghost = document.createElement("input");

            ghost.setAttribute("type", "file");
            let vx = new DataTransfer();

            ghost.files[i] = vx.items.add(i);
            indx = indx+1;

            imageCont.appendChild(ghost);
            console.log(ghost.value);

            reader.onload = () =>{
                const result = reader.result;
                img.setAttribute("src",result)
                img.setAttribute("class","img_var")
                nminput.setAttribute("type","text")
                nminput.classList.add("var_inp")

                nminput.addEventListener("keyup", addName)
                conta.setAttribute("id",i.name)
                conta.appendChild(img)
                conta.appendChild(nminput);
                imgVars.appendChild(conta)
                };

            reader.readAsDataURL(i);
         };
        let x = varsCont.querySelector(".prod-txt")
        let y = files.length;
        x.textContent =y +'files chosen';

     };



};


function createName(){
    preUl.querySelectorAll("li").forEach(li => li.remove());
    Variants.forEach(name =>{
        const liTag = document.createElement("li");
        const remove = document.createElement("span")
        const tagtxt = document.createElement("span")

        tagtxt.innerHTML = name;
        liTag.setAttribute('id',name);
        remove.textContent = 'x';

        liTag.className = "li-tag"
        tagtxt.className = "tag-txt";
        remove.className = "icon-1";


        liTag.appendChild(tagtxt);
        liTag.appendChild(remove);

        preUl.appendChild(liTag);

       removeName();


        });

           countNames();
};




function addName(e) {

     if(e.key == "Control"){
        console.log("name added");
        let name = e.target.value.replace(/\s+/g, '');
        let f = e.target.parentElement;
        let g =e.target
        console.log(f)
        h = f.parentElement;
        j = h.parentElement;
        console.log(j)
        f.parentElement.removeChild(f)
        if(name.length > 1 && !Variants.includes(name)){
                name.split(',').forEach(name=>{
                    Variants.push(name);
                    Variants.reverse();
                    createName();

                });

        }
        e.target.value = "";
    }

}
function removeName(){

        let n = preUl.querySelectorAll('li');
        Array.from(n).forEach(function(h){h.addEventListener("click",deleteName);

});
};
 function deleteName(e){

                let g = e.target.parentElement;
                let f = g.getAttribute('id');
                let m = g.querySelector('.tag-txt');
                let y = m.innerHTML;


                let index = Variants.indexOf(f);

                var lon = Variants.length -1;


                preUl.removeChild(g);
                Variants.splice(index,1);

                countNames()


};


function countNames(){
     var lin = Variants.length ;
     let cont = "";
     for(var i=0; i<lin; i++){

     cont+=Variants[i] +",";
     nameIn.setAttribute("value","");
     nameIn.setAttribute("value",cont);

     };
     console.log(nameIn);
     console.log(nameIn.getAttribute("value"));


}