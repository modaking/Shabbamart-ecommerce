
$(document).ready(function(){

$(".pin_icon").click(function(e){
      var xbt= e.target;
      var pi = e.target.parentElement;
      pi = pi.parentElement;
      pi = pi.getAttribute("id");
      console.log(pi);

      $.ajax({
      data: {
      digit: ""

      },
      type: "GET",
      url:"/add_pin/" + pi})
      .done(function(data){
      console.log(data.digit)
     /* create cart section */
     xbt.setAttribute("src", "/static/icons/done.png")


         })




})


$(".pinned").click(function(e){

     const dob = document.querySelector("body");
     console.log(dob);
     var mmn = dob.querySelector('.pinned_section');
      var prof = dob.querySelector('.prof_section');
     var menu = dob.querySelector('.menu_section');

     var cartt = dob.querySelector('.cart_section');


     if (mmn){
          body.removeChild(mmn);
          body.style.overflow = 'scroll';

     }
     else{ if(cartt){
          body.removeChild(cartt);


       }
       else if(prof){

           body.removeChild(prof);
       }
       else if(menu){

            body.removeChild(menu);
       }

body.style.overflow = 'hidden';

$.ajax({
    data: {

        digit:""

    },type: "GET",
      url:"/view_pin"})
    .done(function(data){

     console.log(data.digit);

     const section = document.createElement("div");
     const titleBox = document.createElement("div");
     const removeIcon = document.createElement("img")
     const galleryBox = document.createElement("div");
     const items = document.createElement("ul");
     var list = data.digit;

     list.forEach(it =>{
        const item = document.createElement("li");
        const card = document.createElement("div");
        const descLink = document.createElement("a");
        const photo = document.createElement("img");
        const detailSection = document.createElement("div");
        const detailTxt = document.createElement("div");
        const nameTxt = document.createElement("span");
        const priceTxt = document.createElement("span");
        const varTxt = document.createElement("span");
        const iconSection = document.createElement("div");
        const unpin = document.createElement("img");
        const cart = document.createElement("img");


        card.classList.add("pinned_card");
        descLink.classList.add("pinned_link");
        photo.classList.add("pinned_photo");
        detailSection.classList.add("pinned_detail");
        detailTxt.classList.add("pinned_txt");
        nameTxt.classList.add("pinned_name");
        priceTxt.classList.add("pinned_price");
        varTxt.classList.add("pinned_var");
        iconSection.classList.add("pinned_btns");
        unpin.classList.add("unpin");
        cart.classList.add("pinned_cart");
        item.classList.add("pinned_item");

        var bv = it['id'];
        bv = bv.replace("p","");
        console.log("bv ->" + bv );
        console.log(it['path'])


        photo.setAttribute("src", it['path']);
        descLink.setAttribute("href", "description/" + bv);
        unpin.setAttribute("src", "/static/icons/close.png");
        cart.setAttribute("src", "/static/icons/add_shopping.png");
        iconSection.setAttribute("id", it['id']);
        nameTxt.textContent =it['name'];
        priceTxt.textContent =" Ksh " +it['price'];
        varTxt.textContent =it['category'];



        iconSection.appendChild(unpin);
        iconSection.appendChild(cart);
        detailTxt.appendChild(nameTxt);
        detailTxt.appendChild(priceTxt);
        detailTxt.appendChild(varTxt);
        detailSection.appendChild(detailTxt);
        detailSection.appendChild(iconSection);
        descLink.appendChild(photo);
        card.appendChild(descLink);
        card.appendChild(detailSection);
        item.appendChild(card);


        items.appendChild(item);


        cart.addEventListener("click", function(e) {


        var xp = e.target.parentElement;
        console.log(xp);
        xp = xp.getAttribute("id");
        console.log(xp);
        xp = xp.replace("p","")
        xp = parseInt(xp);
        console.log("xp ->" + xp )


        $.ajax({
            data: {

        digit:""

    },type: "GET",
      url:"/add_cart/" + xp})
    .done(function(data){
    console.log(data);


    })

       })




 unpin.addEventListener("click", function(e) {



        var xp = e.target.parentElement;
        console.log(xp);
        xp = xp.getAttribute("id");
        console.log(xp);
        xp = xp.replace("p","")
        xp = parseInt(xp);
        console.log("xp ->" + xp )


               $.ajax({
                   data: {
                   result: ""

                   },
                   type: "GET",
                   url:"/del_pin/" + xp})
                  .done(function(data){
                 console.log(data.result)
                 var z = e.target.parentElement.parentElement.parentElement.parentElement;
                 const n = document.querySelector('.pinned_ul');

                 console.log(z);
                 console.log(n);
                  n.removeChild(z);



                    });
               });

    });


     removeIcon.setAttribute("src", "/static/icons/arrow_left.png");
     section.classList.add("pinned_section");
     titleBox.classList.add("pinned_title");
     galleryBox.classList.add("pinned_gallery");
     items.classList.add("pinned_ul");
     removeIcon.classList.add("remove");

     titleBox.appendChild(removeIcon);
     galleryBox.appendChild(items);
     section.appendChild(titleBox);
     section.appendChild(galleryBox);
     dob.appendChild(section);


removeIcon.addEventListener("click", function(e) {
          const bod = document.querySelector("body")
          var tx = e.target.parentElement;
          tx = tx.parentElement;
          console.log(tx)
          bod.removeChild(tx);
          bod.style.overflow = 'scroll';

         });

  })


}})




$(".add_icon").click(function(e){
      var xbt= e.target;
      console.log(xbt)
      var pi = e.target.parentElement;
      pi = pi.parentElement;
      pi = pi.getAttribute("id");
      console.log(pi);



      $.ajax({
      data: {


      },
      type: "GET",
      url:"/add_cart/" + pi})
      .done(function(data){
       xbt.setAttribute("src", "/static/icons/done.png")




});

})


});
